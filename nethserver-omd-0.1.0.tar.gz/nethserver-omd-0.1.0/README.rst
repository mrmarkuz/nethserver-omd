==============
nethserver-omd
==============

OMD is a monitoring system usable via web gui.

Access policy
=============

Set with httpd

