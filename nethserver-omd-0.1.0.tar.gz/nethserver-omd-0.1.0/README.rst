==============
nethserver-omd
==============

OMD is a monitoring system usable via web gui.

Installation
============

You have to install from Consol Labs repository:

NethServer 7:
rpm -Uvh "https://labs.consol.de/repo/stable/rhel7/i386/labs-consol-stable.rhel7.noarch.rpm"

NethServer 6:
rpm -Uvh "https://labs.consol.de/repo/stable/rhel6/i386/labs-consol-stable.rhel6.noarch.rpm"

Install nethserver-omd and browse to https://NETHSERVER/monitor

A site named monitor is created automatically.

You can go to your OMD site monitor via the application menu.

Documentation
=============

https://community.nethserver.org/t/howto-install-omd-labs-edition-nagios-icinga-2-check-mk/7617
